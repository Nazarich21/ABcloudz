﻿using System;
using System.Collections.Generic;

#nullable disable

namespace RailwayAPI
{
    public partial class Station
    {
        public string Id { get; set; }
        public string Name { get; set; }
 
    }
}
